

import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;

public class Visualization {
    private double r = 0.0D;
    private boolean increment = true;
    private double timesTableNum;
    private double radius;

    public Visualization(double timesTableNum, double radius) {
        this.timesTableNum = timesTableNum;
        this.radius = radius;
    }

    public double getR() {
        return this.r;
    }

    public double getRadius() {
        return this.radius;
    }

    public double getTimesTableNum() {
        return this.timesTableNum;
    }

    public void setTimesTableNum(double timesTableNum) {
        this.timesTableNum = timesTableNum;
    }

    public void incrementTimesTableNum(double stepNum) {
        this.timesTableNum += stepNum;
    }

    private void incrementRed() {
        if (Double.compare(this.r, 0.0D) <= 0) {
            this.increment = true;
        }

        if (Double.compare(this.r, 0.8D) >= 0) {
            this.increment = false;
        }

        if (this.increment) {
            this.r += 0.1D;
        }

        if (!this.increment) {
            this.r -= 0.1D;
        }

    }

    public Group generateLines(double numPoints) {
        this.incrementRed();
        Color color = new Color(this.r, Math.random(), Math.random(), 1.0D);
        Group lines = new Group();
        PointOnCircle[] points = PointOnCircle.generatePoints(this.radius, numPoints);
        PointOnCircle[] var6 = points;
        int var7 = points.length;

        for(int var8 = 0; var8 < var7; ++var8) {
            PointOnCircle poc = var6[var8];
            double m = this.getTimesTableNum();
            double d = m * (double)poc.getId();
            double correspondingPointId = d % numPoints;
            PointOnCircle pointTo = points[(int)correspondingPointId];
            PointOnCircle pointFrom = points[poc.getId()];
            Line line = new Line(pointFrom.getX(), pointFrom.getY(), pointTo.getX(), pointTo.getY());
            line.setStroke(color);
            lines.getChildren().add(line);
        }

        return lines;
    }
}

